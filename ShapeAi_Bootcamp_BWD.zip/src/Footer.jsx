import React from "react";

function Footer() {
  return (
    <footer>
      <p>Copyright with ShapeAi @ {new Date().getFullYear()}</p>
    </footer>
  );
}

export default Footer;
