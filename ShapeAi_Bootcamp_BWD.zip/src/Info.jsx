import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>Javascript and ReactJs</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magni
        pariatur, nesciunt doloribus ab unde provident sed ipsum sapiente, nisi
        aliquam similique. 
      </p>
    </div>
  );
}
export default Info;
